import React, {useState} from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Text,
} from 'react-native';

interface InputFieldProps {
  placeholder: string;
  onChangeText: (text: string) => void;
  value: string;
  secureTextEntry?: boolean;
}

const InputField: React.FC<InputFieldProps> = ({
  placeholder,
  onChangeText,
  value,
  secureTextEntry = false,
}) => {
  const [isSecure, setIsSecure] = useState(secureTextEntry);

  const toggleSecureEntry = () => {
    setIsSecure(prevState => !prevState);
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder={placeholder}
        onChangeText={onChangeText}
        value={value}
        secureTextEntry={isSecure}
        placeholderTextColor="#aaa"
      />
      {secureTextEntry && (
        <TouchableOpacity style={styles.eyeButton} onPress={toggleSecureEntry}>
          <Text style={styles.showText}>{isSecure ? 'Show' : 'Hide'}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 15,
  },
  input: {
    height: 55,
    marginHorizontal: 20,
    borderWidth: 1,
    padding: 10,
    borderRadius: 10,
    borderColor: '#ccc',
    backgroundColor: '#E9EAEC',
    fontSize: 16,
    color: '#000',
  },
  eyeButton: {
    position: 'absolute',
    right: 30,
    top: 20,
  },
  showText: {
    color: '#007BFF',
    fontSize: 14,
  },
});

export default InputField;
