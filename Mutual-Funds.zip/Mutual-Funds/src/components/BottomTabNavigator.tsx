import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Image} from 'react-native';

const BottomTabNavigator = () => {
  return (
    <View style={styles.container}>
      <View style={styles.curveContainer}>
        <View style={styles.navigatorContainer}>
          <TouchableOpacity style={styles.iconButton}>
            <Image
              source={require('../assets/home.png')}
              style={styles.icon}
            />
            <Text style={styles.iconText}>Home</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.iconButton}>
            <Image
              source={require('../assets/funds.png')}
              style={styles.icon}
            />
            <Text style={styles.iconText}>Funds</Text>
          </TouchableOpacity>
          <View style={{width: 70}} />
          <TouchableOpacity style={styles.iconButton}>
            <Image
              source={require('../assets/history.png')}
              style={styles.icon}
            />
            <Text style={styles.iconText}>History</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.iconButton}>
            <Image
              source={require('../assets/withdraw.png')}
              style={styles.icon}
            />
            <Text style={styles.iconText}>Withdraw</Text>
          </TouchableOpacity>
        </View>
      </View>

      <TouchableOpacity style={styles.fab}>
        <Image source={require('../assets/plus.png')} style={styles.fabIcon} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  curveContainer: {
    backgroundColor: '#fff',
    width: '100%',
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  navigatorContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
  },
  iconButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
  },
  icon: {
    width: 30,
    height: 30,
  },
  iconText: {
    fontSize: 12,
    color: '#646464',
  },
  fab: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#007BFF',
    justifyContent: 'center',
    alignItems: 'center',
    bottom: 35,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: {height: 5},
    elevation: 6,
  },
  fabIcon: {
    width: 60,
    height: 60,
  },
});

export default BottomTabNavigator;
