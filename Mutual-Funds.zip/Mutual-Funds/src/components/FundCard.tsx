import React from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native';

interface Props {
  name: string;
  type: string;
  annualReturn: string;
  onPress: () => void;
  riskAppetite: string;
  bankId: number;
}

const FundCard: React.FC<Props> = ({
  name,
  type,
  annualReturn,
  riskAppetite,
  onPress,
  bankId,
}) => {
  const annualReturnStyle = {
    color: riskAppetite.toLowerCase() === 'high' ? '#ff0000' : '#00cc44',
    backgroundColor:
      riskAppetite.toLowerCase() === 'high' ? '#ffcccc' : '#e6ffee',
  };

  const logoSource =
    bankId === 1
      ? require('../assets/meezan-bank-logo.png')
      : bankId === 3
      ? require('../assets/hbl-logo.png')
      : require('../assets/meezan-bank-logo.png');

  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        <Image source={logoSource} style={styles.image} />
        <View style={styles.infoContainer}>
          <Text style={styles.name}>{name}</Text>
          <View style={styles.subInfoContainer}>
            <Text style={styles.type}>{type}</Text>
            <Text style={[styles.annualReturn, annualReturnStyle]}>
              {annualReturn}
            </Text>
          </View>
        </View>
      </View>
      <TouchableOpacity onPress={onPress} style={styles.button}>
        <Text style={styles.buttonText}>View Details</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    margin: 10,
    padding: 20,
    marginBottom: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 1.5,
    elevation: 2,
  },
  contentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  image: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  subInfoContainer: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    maxWidth: '50%',
    flexShrink: 1,
    alignItems: 'flex-start',
  },
  name: {
    fontSize: 16,
    marginRight: 10,
    flex: 1,
    flexWrap: 'wrap',
    color: 'black',
  },
  type: {
    fontSize: 10,
    flexWrap: 'wrap',
  },
  annualReturn: {
    fontSize: 10,
    paddingHorizontal: 6,
    borderRadius: 5,
    overflow: 'hidden',
    maxWidth: '100%',
    textAlign: 'center',
  },
  button: {
    marginTop: 10,
    backgroundColor: '#F9FAFB',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  buttonText: {
    color: 'black',
    fontSize: 13,
  },
});

export default FundCard;
