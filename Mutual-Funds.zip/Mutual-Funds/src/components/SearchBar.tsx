import React from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import {useDispatch} from 'react-redux';
import {setToken} from '../redux/slices/userSlice';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SearchBar = () => {
  const dispatch = useDispatch();

  const handleLogout = async () => {
    await AsyncStorage.removeItem('USER_SESSION');
    dispatch(setToken(null));
  };

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <Image
          source={require('../assets/search.png')}
          style={styles.searchIcon}
        />
        <TextInput placeholder="Search Funds" style={styles.input} />
      </View>
      <TouchableOpacity style={styles.filterButton} onPress={handleLogout}>
        <View style={styles.iconContainer}>
          <Image
            source={require('../assets/setting.png')}
            style={styles.searchIcon}
          />
          <Image
            source={require('../assets/drop-down.png')}
            style={styles.searchIcon}
          />
        </View>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: 10,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    flex: 1,
    marginRight: 10,
    borderRadius: 10,
    paddingHorizontal: 10,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
  },
  input: {
    flex: 1,
    paddingVertical: 8,
    fontSize: 16,
  },
  filterButton: {
    width: 65,
    height: 55,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
  },
  iconContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchIcon: {
    width: 20,
    height: 20,
    margin: 5,
  },
});

export default SearchBar;
