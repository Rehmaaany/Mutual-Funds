import React from 'react';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';

interface LoginButtonProps {
  title: string;
  onPress: () => void;
}

const LoginButton: React.FC<LoginButtonProps> = ({title, onPress}) => {
  return (
    <TouchableOpacity style={styles.button} onPress={onPress}>
      <Text style={styles.text}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#6200EE',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginHorizontal: 12,
  },
  text: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default LoginButton;
