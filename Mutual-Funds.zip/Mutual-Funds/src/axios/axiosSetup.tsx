import axios, {AxiosError, AxiosResponse} from 'axios';
import { Alert } from 'react-native';

interface ApiResponse<T = any> {
  code: number;
  data: T;
  message: string;
}
const BASE_URL = 'https://api.getharvest.app';

const apiRequest = axios.create({
  baseURL: BASE_URL,
  responseType: 'json',
  headers: {
    'Content-Type': 'application/json',
  },
});

apiRequest.interceptors.response.use(
  (response: AxiosResponse<ApiResponse>) => {
    console.log('🚀 ~ interceptors ~ api ~ response ~', response);
    if (response.status === 200  || response.status === 201) {
      return Promise.resolve(response);
    }
    return Promise.reject(response);
  },
  (error: AxiosError) => {
    console.log('🚀 ~ interceptors ~ api ~ error ~', error);
    return interceptingErrors(error);
  },
);

const interceptingErrors = (error: AxiosError): Promise<any> => {

  if (!error.response) {
    if (error?.message === 'Network Error') {
      return Promise.reject({
        data: {
          message:
            'No connectivity! Please check your internet connection and try again.',
        },
      });
    }
    Alert.alert('Oops, Something went wrong!.');
    return Promise.reject({data: {message: error?.message}});
  }

  if (error.response.status === 401 && error.response.data.code === 401) {
    Alert.alert('Session Expired, Please Login Again.');
    return Promise.reject(error.response);
  }

  if (!error.response?.data) {
    Alert.alert('Oops, Something went wrong!.');
    return Promise.reject(error);
  }

  if (error.config?.headers?.ShowToastOnError === false) {
    return Promise.reject(error.response);
  }

  Alert.alert(error?.response?.data?.message);
  return Promise.reject(error.response);
};

export const setAuthToken = (token?: string): boolean => {
  if (token) {
    apiRequest.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    return true;
  }
  delete apiRequest.defaults.headers.common['Authorization'];
  return false;
};

export {apiRequest};
