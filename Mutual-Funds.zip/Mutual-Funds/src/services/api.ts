import axios from 'axios';

const API_URL = 'https://api.getharvest.app';

export const loginApi = async (data: any): Promise<any> => {
  const response = await axios.post(API_URL + '/auth/login', data);
  return response.data;
};