import React, {useState} from 'react';
import {
  Modal,
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  Text,
} from 'react-native';
import FundCard from '../../components/FundCard';
import BottomTabNavigator from '../../components/BottomTabNavigator';
import SearchBar from '../../components/SearchBar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useQuery} from '@tanstack/react-query';
import {StorageKey} from '../../services/storage-management';
import {apiRequest} from '../../axios/axiosSetup';

interface Fund {
  id: number;
  isActive: boolean;
  name: string;
  category: string;
  NAV: string;
  purpose: string;
  investment_horizon: string;
  risk_appetite: string;
  last_year_return: number;
  YTD: string;
  FEL: string;
  actual_commission_fees: string;
  commission: string;
  BEL: string | null;
  minimum_investable_amount: number;
  bankId: number;
  tax: string | null;
  lock_in_period: boolean | null;
  createdAt: string;
  updatedAt: string;
}

const API_URL = 'https://api.getharvest.app';

const MutualFundsScreen = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedFund, setSelectedFund] = useState<Fund | null>(null);

  const fetchFunds = async () => {
    const jsonValue = await AsyncStorage.getItem(StorageKey.USER_SESSION);
    const sessionData = jsonValue ? JSON.parse(jsonValue) : null;
    const token = sessionData ? sessionData.token : null;

    if (!token) {
      throw new Error('Authentication token not found');
    }
    const response = await apiRequest.get(`/funds/all`);

    return response.data;
  };

  const {data: funds} = useQuery({
    queryKey: ['funds'],
    queryFn: fetchFunds,
    onError: (error: any) => {
      Alert.alert('Error', error.message || 'Failed to fetch funds');
    },
  });

  const handlePressFund = (fund: Fund) => {
    setSelectedFund(fund);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={funds}
        keyExtractor={item => item.id.toString()}
        renderItem={({item}) => (
          <FundCard
            name={item.name}
            type={item.category}
            annualReturn={`Annual Return: ${item.last_year_return}%`}
            riskAppetite={item.risk_appetite}
            onPress={() => handlePressFund(item)}
            bankId={item.bankId}
          />
        )}
        ListHeaderComponent={
          <View style={styles.searchContainer}>
            <SearchBar />
          </View>
        }
        contentContainerStyle={styles.listContentContainer}
      />
      <BottomTabNavigator />
      {selectedFund && (
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            setModalVisible(!modalVisible);
          }}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalTitle}>Fund Details</Text>
              {selectedFund && (
                <View style={styles.modalContent}>
                  <Text style={styles.modalText}>
                    Name: {selectedFund.name}
                  </Text>
                  <Text style={styles.modalText}>
                    Category: {selectedFund.category}
                  </Text>
                  <Text style={styles.modalText}>NAV: {selectedFund.NAV}</Text>
                  <Text style={styles.modalText}>
                    Purpose: {selectedFund.purpose}
                  </Text>
                  <Text style={styles.modalText}>
                    Investment Horizon: {selectedFund.investment_horizon}
                  </Text>
                  <Text style={styles.modalText}>
                    Risk Appetite: {selectedFund.risk_appetite}
                  </Text>
                  <Text style={styles.modalText}>
                    Last Year Return: {selectedFund.last_year_return}%
                  </Text>
                  <Text style={styles.modalText}>YTD: {selectedFund.YTD}</Text>
                  <Text style={styles.modalText}>
                    Front-End Load (FEL): {selectedFund.FEL}
                  </Text>
                  <Text style={styles.modalText}>
                    Commission: {selectedFund.commission}
                  </Text>
                  <Text style={styles.modalText}>
                    Actual Commission Fees:{' '}
                    {selectedFund.actual_commission_fees}
                  </Text>
                  <Text style={styles.modalText}>
                    Back-End Load (BEL): {selectedFund.BEL || 'N/A'}
                  </Text>
                  <Text style={styles.modalText}>
                    Minimum Investable Amount: $
                    {selectedFund.minimum_investable_amount}
                  </Text>
                  <Text style={styles.modalText}>
                    Bank ID: {selectedFund.bankId}
                  </Text>
                  <Text style={styles.modalText}>
                    Tax: {selectedFund.tax || 'N/A'}
                  </Text>
                  <Text style={styles.modalText}>
                    Lock-in Period: {selectedFund.lock_in_period ? 'Yes' : 'No'}
                  </Text>
                  <Text style={styles.modalText}>
                    Created At: {selectedFund.createdAt}
                  </Text>
                  <Text style={styles.modalText}>
                    Updated At: {selectedFund.updatedAt}
                  </Text>
                </View>
              )}
              <TouchableOpacity
                style={[styles.button, styles.buttonClose]}
                onPress={() => setModalVisible(!modalVisible)}>
                <Text style={styles.textStyle}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    margin: 10,
    borderRadius: 5,
  },
  listContentContainer: {
    paddingBottom: 80,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    maxWidth: '90%',
  },
  modalTitle: {
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 15,
  },
  modalText: {
    textAlign: 'left',
    alignSelf: 'flex-start',
    fontSize: 14,
    marginVertical: 2,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    marginTop: 20,
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalContent: {
    alignSelf: 'stretch',
    alignItems: 'flex-start',
  },
});

export default MutualFundsScreen;
