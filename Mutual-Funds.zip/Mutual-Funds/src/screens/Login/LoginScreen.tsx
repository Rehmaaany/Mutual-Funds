import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Alert} from 'react-native';
import axios from 'axios';
import {useDispatch} from 'react-redux';
import InputField from '../../components/InputField';
import LoginButton from '../../components/LoginButton';
import {setToken} from '../../redux/slices/userSlice';
import {StorageKey} from '../../services/storage-management';
import {useMutation} from '@tanstack/react-query';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {apiRequest, setAuthToken} from '../../axios/axiosSetup';

const LoginScreen = () => {
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [emailError, setEmailError] = useState(false);
  const [pinError, setPinError] = useState(false);
  const dispatch = useDispatch();

  const API_URL = 'https://api.getharvest.app';

  const mutation = useMutation({
    mutationFn: data => {
      return apiRequest.post('/auth/login', data);
    },
    onSuccess: async data => {
      const token = data.data.access_token.replace('Bearer ', '');
      await setAuthToken(token);
      dispatch(setToken(token));
      await AsyncStorage.setItem(
        StorageKey.USER_SESSION,
        JSON.stringify({token}),
      );
    },
    onError: error => {
      Alert.alert('Login Failed', 'Invalid email or password');
      setEmailError(true);
      setPinError(true);
    },
  });

  const handleLogin = async () => {
    setEmailError(false);
    setPinError(false);

    let data = {
      email: email.trim(),
      password: pin.trim(),
    };

    mutation.mutate(data);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <InputField
        placeholder="Email address"
        onChangeText={text => {
          setEmail(text);
          setEmailError(false);
        }}
        value={email}
        isError={emailError}
      />
      <InputField
        placeholder="Login pin"
        secureTextEntry={true}
        onChangeText={text => {
          setPin(text);
          setPinError(false);
        }}
        value={pin}
        isError={pinError}
      />
      <View style={styles.resetContainer}>
        <Text style={styles.resetText}>Forgot pin?</Text>
        <TouchableOpacity onPress={() => alert('Reset Pin')}>
          <Text style={styles.reset}> reset</Text>
        </TouchableOpacity>
      </View>
      <LoginButton title="Login" onPress={handleLogin} />
      <View style={styles.signUpContainer}>
        <Text style={styles.signUpText}>Don’t have an account?</Text>
        <TouchableOpacity onPress={() => alert('Sign Up')}>
          <Text style={styles.signUp}> Sign up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    marginVertical: 10,
    marginLeft: 20,
  },
  resetText: {
    marginLeft: 20,
  },
  reset: {
    color: '#007BFF',
    marginBottom: 20,
  },
  resetContainer: {
    flexDirection: 'row',
  },
  signUpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
  signUpText: {
    textAlign: 'center',
  },
  signUp: {
    color: '#007BFF',
  },
});

export default LoginScreen;
