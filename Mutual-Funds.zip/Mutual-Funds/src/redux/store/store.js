import { createStore, combineReducers } from 'redux';
import { persistStore, persistReducer } from 'redux-persist';
import authReducer from '../actions/authActions';
import userSlice from '../slices/userSlice';
import AsyncStorage from '@react-native-async-storage/async-storage';

const persistConfig = {
  timeout: 10000,
  key: 'root',
  storage: AsyncStorage,
  blacklist: ['auth'] 
};

const initialState = {};

const rootReducer = combineReducers({
  auth: authReducer,
  user: userSlice
});

const persistedReducer = persistReducer(persistConfig, rootReducer);


const store = createStore(
  persistedReducer,
  initialState,
);

const persistor = persistStore(store);

export { store, persistor };
