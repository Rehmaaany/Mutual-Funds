import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import { RootStackParamList } from './navigationTypes';
import LoginScreen from '../screens/Login/LoginScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();

const AuthStack: React.FC = () => {
  return (
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{headerShown: false}}
        />
      </Stack.Navigator>
  );
};

export default AuthStack;
