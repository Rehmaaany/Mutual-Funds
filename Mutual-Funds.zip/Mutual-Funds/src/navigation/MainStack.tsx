import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import MutualFundsScreen from '../screens/FundsStack/MutualFundsScreen';
import { RootStackParamList } from './navigationTypes';

const Stack = createNativeStackNavigator<RootStackParamList>();

const MainStack: React.FC = () => {
  return (
      <Stack.Navigator initialRouteName="MutualFunds">
        <Stack.Screen
          name="MutualFunds"
          component={MutualFundsScreen}
          options={{title: 'Mutual Funds'}}
        />
      </Stack.Navigator>
  );
};

export default MainStack;
