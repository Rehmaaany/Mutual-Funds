import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {RootStackParamList} from './navigationTypes';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Navigation from './Navigation';

const Stack = createNativeStackNavigator<RootStackParamList>();

const StackNavigator: React.FC = () => {


  return (
    <NavigationContainer>
      <Navigation />
    </NavigationContainer>
  );
};

export default StackNavigator;
