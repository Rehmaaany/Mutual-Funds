export type RootStackParamList = {
    Login: undefined; 
    MutualFunds: undefined;
  };
  
  