import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import AuthStack from './AuthStack';
import MainStack from './MainStack';
import { setAuthToken } from '../axios/axiosSetup';

export default function Navigation() {
  const {token} = useSelector(state => state?.user);
  const [isLogged, setIsLogged] = useState(false);

  useEffect(() => {
    setIsLogged(token ? true : false);
    setAuthToken(token)
  }, [token]);

  if (!isLogged) {
    return <AuthStack />;
  } else {
    return <MainStack />;
  }
}
